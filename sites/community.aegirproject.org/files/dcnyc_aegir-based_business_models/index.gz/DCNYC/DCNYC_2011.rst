Aegir-based Business Models
===========================

.. include:: <s5defs.txt>

.. demo-based, q/a at the end

*Presented by*: C. Gervais (ergonlogic) & A. Beaupré (anarcat)

Presenters
----------

Christopher Gervais | ergonlogic | chris@koumbit.org

Antoine Beaupré | anarcat | antoine@koumbit.org


Agenda
------
* What is the Aegir Hosting System?
* Business models
* OpenAtria.com case-study
* Resources


What is the Aegir Hosting System?
---------------------------------

What is the Aegir Hosting System?
---------------------------------
* Tools & functions
* Project components
* People, community & ecosystem


Tools & Functions
-----------------
**"Aegir is an important tool in the toolbox of the Drupal community."**

.. class:: right

-- *Dries Buytaert*


Aegir makes it easy to *install*, *upgrade*, *deploy*, and *backup* an entire network of Drupal sites.

Project
-------
* Free open source software
   * GPL'd
   * Scratch your own itch

**N.B.** there is no "Aegir" project on drupal.org

Components
----------
* Drush extension: Provision_
* Installation profile: Hostmaster_
   * Modules: Hosting_
   * Theme: Eldir_

.. _Provision: http://drupal.org/project/provision
.. _Hostmaster: http://drupal.org/project/hostmaster
.. _Hosting: http://drupalcode.org/project/hostmaster.git/tree/HEAD:/modules/hosting
.. _Eldir: http://drupalcode.org/project/hostmaster.git/tree/HEAD:/themes/eldir

People
------
* Founder/Lead
* Maintainers_
* Contributors
* Users

.. _Maintainers: http://community.aegirproject.org/maintainers

Community
---------
* community.aegirproject.org_
* #aegir on IRC
* `Issue queues`_
* Dev scrums
* DrupalCons & DrupalCamps

.. _community.aegirproject.org: http:community.aegirproject.org
.. _`Issue queues`: http://drupal.org/project/issues?text=&projects=provision,+hosting,+hostslave,+eldir,+Hostmaster+(Aegir)&status=Open&priorities=All&categories=All

Ecosystem
---------
* Development shops
* Hosting companies
* SaaS providers
* Clients



Business models
---------------


Business models
---------------
* Features Lab / Site Factory / Theme Studio
* Infrastructure-as-a-Service
* Platform-as-a-Service
* Software-as-a-Service

Lab / Factory / Studio
----------------------
1. Skilled Drupal developers
2. Features/Git-based dev-test-staging workflow
3. ????...
4. PROFIT!

Lab / Factory / Studio
----------------------
1. Skilled Drupal developers
2. Features/Git-based dev-test-staging workflow
3. Managed Aegir hosting
4. PROFIT!

Infrastructure-as-a-Service
---------------------------
1. Aegir (packaging)
2. Monitoring/support
3. ????...
4. PROFIT!


Infrastructure-as-a-Service
---------------------------
1. Aegir (packaging)
2. Monitoring/support
3. Deep Aegir/sysadmin skillset
4. PROFIT!


Platform-as-a-Service
---------------------
1. Shared Aegir infrastructure
2. uc_hosting
3. ????...
4. PROFIT!

Platform-as-a-Service
---------------------
1. Shared Aegir infrastructure
2. uc_hosting
3. Solutions to some security challenges
4. PROFIT!

Software-as-a-Service
---------------------
1. Install profiles
2. Aegir/uc_hosting
3. ????...
4. PROFIT!

Software-as-a-Service
---------------------
1. Install profiles
2. Aegir/uc_hosting
3. Hosting Profile Roles, &c.
4. PROFIT!

OpenAtria.com case-study
------------------------
* Walk-through

Resources
---------
* community.aegirproject.org: Handbook, FAQ, Discussions
* Issue queues
* #aegir on IRC
* Aegir Service Providers

Questions?
-------------------

* Did we miss anything?
* Got a feature suggestion?
* How could *you* use Aegir?

.. class:: big

**THANK YOU!**
